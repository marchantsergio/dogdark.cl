/*
 * Copyright (c) 2015 A8CAS developers (see AUTHORS)
 *
 * This file is part of the A8CAS project which allows to manipulate tape
 * images for Atari 8-bit computers.
 *
 * A8CAS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * A8CAS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along
 * with A8CAS; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA.
 */

#include <stdint.h>

#include "pokey_serialize.h"

#include "a8cas.h"

void POKEY_SERIALIZE_put(POKEY_SERIALIZE_t *serialize, uint8_t byte)
{
	serialize->current_10bit = ((unsigned int)byte << 1) | 0x200;
	serialize->bit_mask = 1;
}

int POKEY_SERIALIZE_get(POKEY_SERIALIZE_t *serialize, A8CAS_signal *sig)
{
	char current;

	sig->length = 0;

	sig->signal = (serialize->current_10bit & serialize->bit_mask) != 0;
	while (serialize->bit_mask != 0x400
	       && (current = (serialize->current_10bit & serialize->bit_mask) != 0) == sig->signal) {
		sig->length ++;
		(serialize->bit_mask) <<= 1;
	};
	sig->rate = serialize->baudrate;

	/* Return non-zero if we reached end of byte. */
	return serialize->bit_mask == 0x400;
}