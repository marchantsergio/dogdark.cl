/*
 * Copyright (c) 2015 A8CAS developers (see AUTHORS)
 *
 * This file is part of the A8CAS project which allows to manipulate tape
 * images for Atari 8-bit computers.
 *
 * A8CAS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * A8CAS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along
 * with A8CAS; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA.
 */
#define DEBUG_LOG 0

#include <assert.h>
#include <math.h>
#if DEBUG_LOG
#include <inttypes.h>
#else
#include <stdint.h>
#endif
#include <stdlib.h>

#include "pokey_deserialize.h"

#include "a8cas.h"
#include "a8cas_file.h"

/* Minimum length of a MARK signal to be considered an IRG, in seconds */
#define MIN_IRG_LENGTH_S 0.05

#define MAX_NOISE_LENGTH 0.01

/* ======== Functions for manipulating the circular signals buffer ======== */

static void add_signal(POKEY_DESERIALIZE_t *deserialize, double length, POKEY_DESERIALIZE_off_t offset)
{
	assert((deserialize->bit_signals.r_pos + deserialize->bit_signals.fill) % deserialize->bit_signals.buf_size == deserialize->bit_signals.w_pos);

	deserialize->bit_signals.buf[deserialize->bit_signals.w_pos].length = length;
	deserialize->bit_signals.buf[deserialize->bit_signals.w_pos ++].offset = offset;
	deserialize->bit_signals.sum += length;
	deserialize->bit_signals.fill ++;
	if (deserialize->bit_signals.w_pos >= deserialize->bit_signals.buf_size)
		deserialize->bit_signals.w_pos = 0;
	assert(deserialize->bit_signals.fill <= deserialize->bit_signals.buf_size);
	assert((deserialize->bit_signals.r_pos + deserialize->bit_signals.fill) % deserialize->bit_signals.buf_size == deserialize->bit_signals.w_pos);
}

static void remove_signals(POKEY_DESERIALIZE_t *deserialize, unsigned int num)
{
	assert((deserialize->bit_signals.r_pos + deserialize->bit_signals.fill) % deserialize->bit_signals.buf_size == deserialize->bit_signals.w_pos);
	assert(deserialize->bit_signals.fill >= num);

	if ((deserialize->bit_signals.fill -= num) == 0) {
		deserialize->bit_signals.sum = 0.0;
		deserialize->bit_signals.r_pos = deserialize->bit_signals.w_pos;
	} else {
		while (num > 0) {
			deserialize->bit_signals.sum -= deserialize->bit_signals.buf[deserialize->bit_signals.r_pos].length;
			if (++deserialize->bit_signals.r_pos >= deserialize->bit_signals.buf_size)
				deserialize->bit_signals.r_pos = 0;
			num --;
		}
	}

	assert((deserialize->bit_signals.r_pos + deserialize->bit_signals.fill) % deserialize->bit_signals.buf_size == deserialize->bit_signals.w_pos);
}

static void remove_signal(POKEY_DESERIALIZE_t *deserialize)
{
	remove_signals(deserialize, 1);
}

static POKEY_DESERIALIZE_bit_signal_t *current_bit_signal(POKEY_DESERIALIZE_t const *deserialize)
{
	assert(deserialize->bit_signals.fill > 0);
	return &deserialize->bit_signals.buf[deserialize->bit_signals.r_pos];
}

static char current_signal(POKEY_DESERIALIZE_t const *deserialize)
{
	assert(deserialize->bit_signals.fill > 0);
	return (deserialize->bit_signals.r_pos & 1) ^ 1;
}

/* Adds VALUE to length of the current signal in the bit_signals buffer. */
static void adjust_current_signal_length(POKEY_DESERIALIZE_t *deserialize, double value)
{
	assert(deserialize->bit_signals.fill > 0);
	deserialize->bit_signals.buf[deserialize->bit_signals.r_pos].length += value;
	deserialize->bit_signals.sum += value;
}

static POKEY_DESERIALIZE_bit_signal_t *bit_signal_at(POKEY_DESERIALIZE_t const *deserialize, unsigned int idx)
{
	assert(idx < deserialize->bit_signals.buf_size);
	assert(deserialize->bit_signals.fill > idx);
	return &deserialize->bit_signals.buf[(deserialize->bit_signals.r_pos + idx) % deserialize->bit_signals.buf_size];
}

#if DEBUG_LOG
static void debug_write_signals(POKEY_DESERIALIZE_t *deserialize)
{
	unsigned int i;

	A8CAS_log(deserialize->file, "Offset=%u, Number of buffered signals=%u: ", deserialize->bit_signals.r_pos, deserialize->bit_signals.fill);
	for (i = 0; i < deserialize->bit_signals.fill; i ++)
		A8CAS_log(deserialize->file, " %f/%u", bit_signal_at(deserialize, i)->length, i & 1 );
	A8CAS_log(deserialize->file, "\n");
}
#endif

/* ======== */

/* After reading a byte, adjust the read baudrate a little in the middle of
   a DATA block, to prevent eventual framing errors in very long blocks. */
static void adjust_bit_length(POKEY_DESERIALIZE_t *deserialize, double byte_length)
{
	double new_bit_length = byte_length / 10.0;
	double max_bit_length = deserialize->bit_length * 1.1;
	double min_bit_length = deserialize->bit_length * 0.9;
	
	if (new_bit_length < max_bit_length && new_bit_length > min_bit_length) {
		/* New bit length does not vary too much, so adjust the baudrate. */
/*		double old_bit_length = deserialize->bit_length;*/
		/* The computation in its original form: */
		deserialize->bit_length *= (new_bit_length / deserialize->bit_length - 1.0) / 10.0 + 1.0;
/*		deserialize->bit_length = new_bit_length / 10.0 + 0.9 * deserialize->bit_length;*/
/*		A8CAS_log(deserialize->file, "bitrate adjusted: %f -> %f (%f) at byte %u\n", old_bit_length, deserialize->bit_length, new_bit_length, deserialize->num_bytes);*/
	}
}

static POKEY_DESERIALIZE_datatype init_process_block_header(POKEY_DESERIALIZE_t *deserialize);
static POKEY_DESERIALIZE_datatype process_irg(POKEY_DESERIALIZE_t *deserialize);
static POKEY_DESERIALIZE_datatype process_fsk_signals(POKEY_DESERIALIZE_t *deserialize);

static POKEY_DESERIALIZE_datatype process_noise_after_data_block(POKEY_DESERIALIZE_t *deserialize)
{
	do {
		double length = current_bit_signal(deserialize)->length;
		if (length > MAX_NOISE_LENGTH) {
			deserialize->process_func = &process_irg;
			return process_irg(deserialize);
		}

		deserialize->next_irg += length;
		remove_signal(deserialize);
	} while (deserialize->bit_signals.fill != 0);

	if (deserialize->in_flush) {
		deserialize->process_func = &process_irg;
		return process_irg(deserialize);
	}
	return POKEY_DESERIALIZE_NONE;
}

static void merge_signals(POKEY_DESERIALIZE_recognize_byte_t *signals, unsigned int pos, unsigned int *fill)
{
	unsigned int i, j;
	assert(pos >= 1);
	assert(pos < *fill - 1);
	
	signals[pos-1].length += signals[pos].length + signals[pos+1].length;
	for (i = pos, j = pos + 2; j < *fill; i ++, j ++) {
		signals[i] = signals[j];
	}
	*fill -= 2;
}

static int recognize_byte(POKEY_DESERIALIZE_t *deserialize, double byte_length)
{
	POKEY_DESERIALIZE_recognize_byte_t *signals = deserialize->recognize_byte_buf;
	double min_length = deserialize->bit_length * 0.1; /* Anything shorted will be ignored */

	unsigned int read_offset = 0;
	unsigned int fill;
	double sum = 0.0;

	unsigned int i;

	unsigned int pos;
	double position;
	uint16_t byte = 0;
	unsigned int mask = 0x01;
	unsigned int num_of_end_mark_bits = 1;

	double min_dist_from_bit_change_pos = deserialize->bit_length * (0.5 - deserialize->bit_deviation);

	{
		double real_sum = 0.0;
/*		A8CAS_log(deserialize->file, "sum: %f, byte_length: %f\n", deserialize->bit_signals.sum, byte_length);*/
		while (real_sum < byte_length) {
/*			A8CAS_log(deserialize->file, "d1 sum: %f\n", sum);*/
			double length = bit_signal_at(deserialize, read_offset)->length;
			real_sum += length;
/*			A8CAS_log(deserialize->file, "d2\n");*/
			if (read_offset & 0x01)
				length -= deserialize->bit_1_0_diff;
			else
				length += deserialize->bit_1_0_diff;
			if (length < 0.0)
				length = 0.0;
			signals[read_offset].length = length;
			signals[read_offset].start = sum;
			sum += length;
			read_offset ++;
		}
	}

	adjust_bit_length(deserialize, sum);

	if (read_offset & 1) { /* Odd number of signals read, therefore the last is "0" */
		A8CAS_log(deserialize->file, "Framing error at byte %u\n", deserialize->num_bytes);
		return 0;
	}

	if (sum > deserialize->bit_length * (10.0 + deserialize->stop_bit_deviation) &&
	    sum < deserialize->bit_length * 15.0) { /* Too long stop bit */
		A8CAS_log(deserialize->file, "Too long stop bit at byte %u\n", deserialize->num_bytes);
		return 0;
	}

	fill = read_offset;

	/* Merge too short signals - treat them as minor "interference". */
	for (i = 2; i < fill - 1; ) {
		if (signals[i].length < min_length) {
			/* Merge this signal with its neighbour(s). */
			if (signals[i+1].length >= min_length || i+1 == fill-1) {
				merge_signals(signals, i, &fill);
				continue;
			} else {
				double delete_i_pos = (signals[i+1].start+signals[i+1].length) / deserialize->bit_length;
				double delete_i1_pos = signals[i].start / deserialize->bit_length;
				/* Compute distances from the ideal bit border positions. */
				delete_i_pos = fabs(delete_i_pos - round(delete_i_pos));
				delete_i1_pos = fabs(delete_i1_pos - round(delete_i1_pos));
				assert(delete_i_pos <= 0.5);
				assert(delete_i1_pos <= 0.5);
				if (delete_i_pos < delete_i1_pos)
					merge_signals(signals, i, &fill);
				else
					merge_signals(signals, i+1, &fill);
			}
		} else
			i ++;
	}

	/* Decode a byte. */
	pos = 0;
	i = 0;
	position = deserialize->bit_length * (deserialize->bit_middle + pos);
	for (;;) {
		if (!(signals[i].start < position && signals[i].start + signals[i].length > position)) {
			/* Found a signal between recognized bits. */
			A8CAS_log(deserialize->file, "Too short signal at byte %u, signal %u\n", deserialize->num_bytes, i);
			return 0;
		}
		if (position - signals[i].start < min_dist_from_bit_change_pos ||
		    signals[i].start + signals[i].length - position < min_dist_from_bit_change_pos) {
			A8CAS_log(deserialize->file, "Ambiguous bit at byte %u, signal %u\n", deserialize->num_bytes, i);
			return 0;
		}
		
		if (i & 1) {
			byte |= mask;
			num_of_end_mark_bits ++;
		} else
			num_of_end_mark_bits = 1;
		mask <<= 1;
		pos ++;
		if (pos >= 9)
			break;
		position = deserialize->bit_length * (deserialize->bit_middle + pos);
		if (signals[i].start + signals[i].length < position)
			i ++;
	}

	byte >>= 1;
/*	{
		unsigned int i;
		A8CAS_log(deserialize->file, "byte: %x!! pos: %u, size: %u, bit_length: %f diff: %f\n", (unsigned int)byte, deserialize->num_bytes, deserialize->bit_signals.fill, deserialize->bit_length, deserialize->bit_1_0_diff);
		for (i = 0; i < deserialize->bit_signals.fill; i ++)
			A8CAS_log(deserialize->file, "%f ", bit_signal_at(deserialize, i)->length);
		A8CAS_log(deserialize->file, "\n");
	}*/
	deserialize->byte = byte;
	++(deserialize->num_bytes);

	assert(read_offset <= deserialize->bit_signals.fill);
	assert(read_offset >= 1);

	remove_signals(deserialize, read_offset - 1);

	assert(current_signal(deserialize) == 1);

	adjust_current_signal_length(deserialize, -deserialize->bit_length * num_of_end_mark_bits);
	return 1;
}

static POKEY_DESERIALIZE_datatype process_data_bytes(POKEY_DESERIALIZE_t *deserialize)
{
	double byte_length = deserialize->bit_length * (9.0 + deserialize->bit_middle);

	if (deserialize->bit_signals.sum < byte_length) {
		/* Not enough length of signals to decode a single byte. */
		if (deserialize->bit_signals.fill >= 20) {
			/* ... But there's no free space in the buffer. */
			/* Assume it's noise. */
			deserialize->process_func = &process_noise_after_data_block;
			return process_noise_after_data_block(deserialize);
		}
		if (deserialize->in_flush)
			return init_process_block_header(deserialize);
		else
			return POKEY_DESERIALIZE_NONE;
	}

	/* Adjust the byte's length. */
	{
		double sum = 0.0;
		unsigned int offset = 0;

		while (sum < byte_length) {
			double length = bit_signal_at(deserialize, offset)->length;
			sum += length;
			offset ++;
		}
		adjust_bit_length(deserialize, sum);
	}

	if (!recognize_byte(deserialize, byte_length)) {
		if (deserialize->num_bytes > 0) {
			deserialize->num_bytes = 0;
			return init_process_block_header(deserialize);
		}
		else {
			deserialize->process_func = &process_fsk_signals;
			return process_fsk_signals(deserialize);
		}
	}

	if (current_bit_signal(deserialize)->length >= deserialize->bit_length * deserialize->bit_deviation) {
		/* Write DATA block. */
		A8CAS_log(deserialize->file, "End of data block at byte %u, found IRG=%f\n", deserialize->num_bytes, current_bit_signal(deserialize)->length);
		deserialize->process_func = &process_irg;
	} else {
		/* Remove surplus MARK signal remnant from the previous stop bit. */
		remove_signal(deserialize);
	}

	return POKEY_DESERIALIZE_BYTE;
}

static POKEY_DESERIALIZE_datatype process_fsk_signals(POKEY_DESERIALIZE_t *deserialize)
{
/* Replace with this line if you want to continue recognizing bytes after each fsk signal
	if (current_signal(deserialize)) {
*/
	if (current_signal(deserialize) && current_bit_signal(deserialize)->length >= MIN_IRG_LENGTH_S) {
		deserialize->process_func = &process_irg;
		return process_irg(deserialize);
	}
	return POKEY_DESERIALIZE_SIGNAL;
}

/* Asjusts the bit_1_0_diff variable in order to nivelate the length
   differences between MARK and SPACE bits, which otherwise would hamper
   deserializing in high baudrates (> 1400). */
static void adjust_bit_1_0_diff(POKEY_DESERIALIZE_t *deserialize)
{
	unsigned int i;
	if (deserialize->bit_signals.fill >= 20) {
		double min_length = deserialize->bit_length * (1.0 - deserialize->block_header_deviation);
		double max_length = deserialize->bit_length * (1.0 + deserialize->block_header_deviation);

		double length0 = 0.0;
		double length1 = 0.0;

		for (i = 0; i < 20; i ++) {
			double length = bit_signal_at(deserialize, i)->length;
			if (length > max_length || length < min_length) {
				return;
			}
			if (i & 1)
				length1 += length;
			else
				length0 += length;
		}

		deserialize->bit_1_0_diff = (length1 - length0) / 20.0;
		/* Divide by 20 to get half the difference between MARK and SPACE bit lengths. */
		A8CAS_log(deserialize->file, "Adjusted bit_1_0_diff = %f\n", deserialize->bit_1_0_diff);
	}
}

/* Returns 1 on success, 0 on failure. */
static int is_byte_length_good(POKEY_DESERIALIZE_t *deserialize, double *byte_length, unsigned int signals_to_check, double *deviation_sum)
{
	double bit_length = *byte_length / 10.0;
	unsigned int i;
	double next_full_byte = *byte_length;
	double all_sum = 0.0;
	double old_sum = 0.0;
	unsigned int bytes_num = 0;

	*deviation_sum = 0.0;

	/* Check for framing errors. */
	for (i = 0; i < signals_to_check; i += 2) {
		if (bit_signal_at(deserialize, i + 1)->length >= MIN_IRG_LENGTH_S) {
			/* Do not inlude the ending IRG signal in the measurement. */
			if (bytes_num == 0)
				return 0;
			break;
		}
		all_sum += bit_signal_at(deserialize, i)->length + bit_signal_at(deserialize, i + 1)->length;
		if (all_sum < next_full_byte - deserialize->block_header_deviation * bit_length)
			/* Not a framing bit yet */
			continue;
		if (all_sum > next_full_byte + deserialize->block_header_deviation * bit_length) {
			/* Framing error */
#if DEBUG_LOG
			A8CAS_log(deserialize->file, "framing error at %u(%f) - sum=%f, NFB=%f\n", i + 1, bit_signal_at(deserialize, i + 1)->length, all_sum, next_full_byte);
#endif
			return 0;
		}
		next_full_byte = all_sum + *byte_length;
		old_sum = all_sum;
		bytes_num ++;
	}
	/* No framing errors found. */

	*byte_length = old_sum / bytes_num;
	/* *BYTE_LENGTH has been adjusted. Now check whether bit lengths are
	   around 1/10 of the byte length. */
	bit_length = *byte_length / 10.0;
#if DEBUG_LOG
	A8CAS_log(deserialize->file, "Adjusted byte length=%f, bit length=%f, i=%u\n", *byte_length, bit_length, i);
#endif
	for (i = 0; i < signals_to_check; i ++) {
		double length = bit_signal_at(deserialize, i)->length;
		double num_bits;
		double scaled_length = length / bit_length;
		double deviation;
		/* If we've encountered an IRG, then assume that the byte is OK. */
		if (length >= MIN_IRG_LENGTH_S && (i & 1)) {
			return 1;
		}
		num_bits = round(scaled_length);
		if (num_bits == 0.0)
			num_bits = 1.0;
#if DEBUG_LOG
		A8CAS_log(deserialize->file, "sigtocheck: %i=%f, num_bits=%f, scaled_length=%f\n", i, length, num_bits, scaled_length);
#endif
		deviation = fabs(scaled_length - num_bits);
		if (deviation > deserialize->block_header_deviation) {
			/* Too much deviation in bit length. */
#if DEBUG_LOG
			A8CAS_log(deserialize->file, "deviation at %u(%f) - scaled length=%f, max deviation=%f\n", i, length, scaled_length, deserialize->block_header_deviation);
#endif
			return 0;
		}
		*deviation_sum += deviation;
	}
	return 1;
}

/* Examines the first few signals of a new block in order to find the block's
   baudrate. Recognizes standard and non-standard blocks (ie. starting or not
   starting with 0x55 55). Checks for framing errors.
   If found, stores the bit length and baudrate on deserialize->bit_length and
   deserialize_baudrate, and returns 1; otherwise returns 0. */
static int detect_baudrate(POKEY_DESERIALIZE_t *deserialize)
{
	unsigned int i;
	double all_sum = 0.0;
	double result_byte_length = 0.0;
	unsigned int signals_to_check = deserialize->bit_signals.fill & ~(unsigned int)0x1; /* Even value */

	/* Safe assumption - each signal can add at most 1.0 to the deviation. */
	double min_deviation = 2.0 * signals_to_check;

#if DEBUG_LOG
	debug_write_signals(deserialize);
#endif
	A8CAS_log(deserialize->file, "Attempting to recognize data block...");
	/* Assume that there are at least 2 signals in SIGNAL_LENGTHS. */
	for (i = 0; i < signals_to_check; i += 2) {
		double byte_length;
		double deviation;
		all_sum += bit_signal_at(deserialize, i)->length + bit_signal_at(deserialize, i + 1)->length;
		byte_length = all_sum;

#if DEBUG_LOG
		A8CAS_log(deserialize->file, "proposed byte length: %f, bit length: %f\n", byte_length, byte_length / 10.0);
#endif
		if (is_byte_length_good(deserialize, &byte_length, signals_to_check, &deviation) &&
		    deviation <= min_deviation) {
			result_byte_length = byte_length;
			/* Multiply by 1.0001 to account fp-math inexactness (when comparing zeros). */
			min_deviation = deviation + 0.0001;
		}
		
	}
	if (result_byte_length == 0.0) {
		A8CAS_log(deserialize->file, " failed\n");
		return 0;
	}

	deserialize->bit_length = result_byte_length / 10.0;
	deserialize->baudrate = 1.0 / deserialize->bit_length;
	A8CAS_log(deserialize->file, " succeeded: bit_length=%f\n", deserialize->bit_length);
	adjust_bit_1_0_diff(deserialize);
	return 1;
}

static POKEY_DESERIALIZE_datatype force_process_block_header(POKEY_DESERIALIZE_t *deserialize)
{
	/* Avoid recognizing isolated "bumps" as bytes. If number of stored
	   signals is < 4, then it's an isolated bump. */
	if (deserialize->bit_signals.fill >= 4 &&
	    detect_baudrate(deserialize)) {
		deserialize->num_bytes = 0;
		deserialize->process_func = &process_data_bytes;
	}
	else
		/* It's not a DATA block. */
		deserialize->process_func = &process_fsk_signals;
	return (*deserialize->process_func)(deserialize);
}


static POKEY_DESERIALIZE_datatype process_block_header(POKEY_DESERIALIZE_t *deserialize)
{
	if (deserialize->in_flush)
		return force_process_block_header(deserialize);

	/* Wait for enough header signals. */
	while (deserialize->bit_signals.chk_pos < deserialize->bit_signals.fill) {
		if ((deserialize->bit_signals.chk_pos & 1) &&
		    bit_signal_at(deserialize, deserialize->bit_signals.chk_pos)->length > MIN_IRG_LENGTH_S)
			return force_process_block_header(deserialize);
		deserialize->bit_signals.chk_pos ++;
	}

	if (deserialize->bit_signals.fill >= deserialize->block_header_length) {
		if (detect_baudrate(deserialize)) {
			deserialize->num_bytes = 0;
			deserialize->process_func = &process_data_bytes;
		}
		else
			deserialize->process_func = &process_fsk_signals;
		return (*deserialize->process_func)(deserialize);
	}
	return POKEY_DESERIALIZE_NONE;
}

static POKEY_DESERIALIZE_datatype init_process_block_header(POKEY_DESERIALIZE_t *deserialize)
{
	deserialize->bit_signals.chk_pos = 0;
	deserialize->process_func = &process_block_header;
	return process_block_header(deserialize);
}

static POKEY_DESERIALIZE_datatype process_irg(POKEY_DESERIALIZE_t *deserialize)
{
	if (current_signal(deserialize)) {
		adjust_current_signal_length(deserialize, deserialize->next_irg);
		deserialize->next_irg = 0.0;
		return POKEY_DESERIALIZE_SIGNAL;
	}

	A8CAS_log(deserialize->file, "new block...\n");
	return init_process_block_header(deserialize);
}

static POKEY_DESERIALIZE_datatype process_next_signal(POKEY_DESERIALIZE_t *deserialize)
{
	double length = deserialize->sig.length;
	assert(((deserialize->bit_signals.w_pos & 0x1) ^ 0x1) == deserialize->sig.signal);

	add_signal(deserialize, length, deserialize->sig.offset);
	return (*deserialize->process_func)(deserialize);
}

static POKEY_DESERIALIZE_datatype process_remaining_bit_signals(POKEY_DESERIALIZE_t *deserialize)
{
	if (deserialize->bit_signals.fill == 0) {
		if (deserialize->in_flush) {
			POKEY_DESERIALIZE_reset(deserialize);
		}
		return POKEY_DESERIALIZE_NONE;
	}
	return (*deserialize->process_func)(deserialize);
}

void POKEY_DESERIALIZE_init(POKEY_DESERIALIZE_t *deserialize, A8CAS_FILE *file)
{
	deserialize->bit_deviation = 0.25;
	deserialize->stop_bit_deviation = 10000.0;
	deserialize->bit_middle = 0.5;
	deserialize->block_header_deviation = 0.5;
	deserialize->bit_signals.buf = NULL;
	deserialize->recognize_byte_buf = NULL;
	deserialize->file = file;
}

A8CAS_errnum POKEY_DESERIALIZE_alloc(POKEY_DESERIALIZE_t *deserialize)
{
	return POKEY_DESERIALIZE_set_block_header_length(deserialize, 20);
}

void POKEY_DESERIALIZE_free(POKEY_DESERIALIZE_t *deserialize)
{
	if (deserialize->recognize_byte_buf != NULL) {
		free(deserialize->recognize_byte_buf);
		deserialize->recognize_byte_buf = NULL;
	}
	if (deserialize->bit_signals.buf != NULL) {
		free(deserialize->bit_signals.buf);
		deserialize->bit_signals.buf = NULL;
	}
}

void POKEY_DESERIALIZE_reset(POKEY_DESERIALIZE_t *deserialize)
{
	deserialize->sig.signal = 1;
	deserialize->sig.length = 0.0;
	deserialize->next_irg = 0.0;
	deserialize->bit_signals.fill = 0;
	deserialize->bit_signals.r_pos = deserialize->bit_signals.w_pos = 0;
	deserialize->bit_signals.sum = 0.0;
	deserialize->bit_length = 0.0;
	deserialize->bit_1_0_diff = 0.0;
	deserialize->in_flush = 0;
	deserialize->process_func = &process_irg;
}

POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_put(POKEY_DESERIALIZE_t *deserialize, A8CAS_signal const *sig)
{
	return POKEY_DESERIALIZE_put_with_offset(deserialize, sig, 0);
}

POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_put_with_offset(POKEY_DESERIALIZE_t *deserialize, A8CAS_signal const *sig, POKEY_DESERIALIZE_off_t offset)
{
	POKEY_DESERIALIZE_datatype retval = POKEY_DESERIALIZE_NONE;
	double length = (double) sig->length / sig->rate;

	if (deserialize->sig.signal == sig->signal)
		deserialize->sig.length += length;
	else {
/*		A8CAS_log(deserialize->file, "write sig: %i, len: %f\n", deserialize->sig.signal, deserialize->sig.length);*/
		if (deserialize->sig.length == 0.0) {
			/* First signal ever (or first signal after rewind). */
			assert(sig->signal == 0);
			assert(deserialize->bit_signals.fill == 0);
			deserialize->bit_signals.w_pos = deserialize->bit_signals.r_pos = 1;
		} else
			retval = process_next_signal(deserialize);
		deserialize->sig.signal = sig->signal;
		deserialize->sig.length = length;
		deserialize->sig.offset = offset;
	}
	return retval;
}

POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_flush(POKEY_DESERIALIZE_t *deserialize)
{
	deserialize->in_flush = 1;
	if (deserialize->sig.length > 0.0) {
/*		A8CAS_log(deserialize->file, "write sig: %i, len: %f\n", deserialize->sig.signal, deserialize->sig.length);*/
		POKEY_DESERIALIZE_datatype type = process_next_signal(deserialize);
		if (type == POKEY_DESERIALIZE_NONE)
			POKEY_DESERIALIZE_reset(deserialize);
		return type;
	}

	return process_remaining_bit_signals(deserialize);
}

POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_get_signal(POKEY_DESERIALIZE_t *deserialize, uint8_t *value, double *length)
{
	*value = current_signal(deserialize);
	*length = current_bit_signal(deserialize)->length;
	remove_signal(deserialize);
/*	A8CAS_log(deserialize->file, "Deserialize: get_signal: %" PRIu8 " %f\n", *value, *length);*/
	return process_remaining_bit_signals(deserialize);
}

POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_get_byte(POKEY_DESERIALIZE_t *deserialize, uint8_t *byte, double *baudrate)
{
	*byte = deserialize->byte;
	*baudrate = deserialize->baudrate;
/*	A8CAS_log(deserialize->file, "Deserialize: get_byte: %02" PRIu8 " %f\n", *byte, *baudrate);*/
	return process_remaining_bit_signals(deserialize);
}

POKEY_DESERIALIZE_off_t POKEY_DESERIALIZE_buffered_signal_offset(POKEY_DESERIALIZE_t const *deserialize)
{
	if (deserialize->bit_signals.fill > 0)
		return current_bit_signal(deserialize)->offset;
	else if (deserialize->sig.length > 0.0)
		return deserialize->sig.offset;
	else
		return -1;
}

/* Functions for setting parameters. */
A8CAS_errnum POKEY_DESERIALIZE_set_bit_deviation(POKEY_DESERIALIZE_t *deserialize, double value)
{
	if (value < 0.0 || value > 0.5)
		return A8CAS_ERR_INVALID;
	deserialize->bit_deviation = value;
	return A8CAS_ERR_NONE;
}

A8CAS_errnum POKEY_DESERIALIZE_set_stop_bit_deviation(POKEY_DESERIALIZE_t *deserialize, double value)
{
	if (value < 0.0)
		return A8CAS_ERR_INVALID;
	deserialize->stop_bit_deviation = value;
	return A8CAS_ERR_NONE;
}

A8CAS_errnum POKEY_DESERIALIZE_set_bit_middle(POKEY_DESERIALIZE_t *deserialize, double value)
{
	if (value < 0.0 || value > 1.0)
		return A8CAS_ERR_INVALID;
	deserialize->bit_middle = value;
	return A8CAS_ERR_NONE;
}

A8CAS_errnum POKEY_DESERIALIZE_set_block_header_length(POKEY_DESERIALIZE_t *deserialize, unsigned int value)
{
	if (value < 10 || (value & 1))
		return A8CAS_ERR_INVALID;
	if (deserialize->bit_signals.buf != NULL &&
	    deserialize->bit_signals.fill != 0)
		return A8CAS_ERR_NOMATCH;
	POKEY_DESERIALIZE_free(deserialize);
	deserialize->bit_signals.w_pos = deserialize->bit_signals.r_pos = 0;

	/* Function process_data_bytes() requires the bit_signals buffer size to be at least 20. */
	deserialize->bit_signals.buf_size = value < 20 ? 20 : value;
	if ((deserialize->bit_signals.buf = malloc(sizeof(POKEY_DESERIALIZE_bit_signal_t) * deserialize->bit_signals.buf_size)) == NULL ||
	    (deserialize->recognize_byte_buf = malloc(sizeof(POKEY_DESERIALIZE_recognize_byte_t) * deserialize->bit_signals.buf_size)) == NULL)
		return A8CAS_ERR_NOMEM;
	deserialize->block_header_length = value;
	return A8CAS_ERR_NONE;
}

A8CAS_errnum POKEY_DESERIALIZE_set_block_header_deviation(POKEY_DESERIALIZE_t *deserialize, double value)
{
	if (value < 0.0)
		return A8CAS_ERR_INVALID;
	deserialize->block_header_deviation = value;
	return A8CAS_ERR_NONE;
}
