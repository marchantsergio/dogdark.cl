/*
 * Copyright (c) 2015 A8CAS developers (see AUTHORS)
 *
 * This file is part of the A8CAS project which allows to manipulate tape
 * images for Atari 8-bit computers.
 *
 * A8CAS is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * A8CAS is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along
 * with A8CAS; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA.
 */
#ifndef POKEY_DESERIALIZE_H
#define POKEY_DESERIALIZE_H

#include <stdint.h>

#include "a8cas.h"
#include "config.h"

/* Size of POKEY_DESERIALIZE_off_t should be large enough to hold long and
   sf_count_t. */
#if SIZEOF_LONG >= SIZEOF_SF_COUNT_T
typedef long POKEY_DESERIALIZE_off_t;
#else
# include <sndfile.h>
typedef sf_count_t POKEY_DESERIALIZE_off_t;
#endif

typedef struct POKEY_DESERIALIZE_bit_signal_t {
	double length;
	POKEY_DESERIALIZE_off_t offset;
} POKEY_DESERIALIZE_bit_signal_t;

typedef struct POKEY_DESERIALIZE_recognize_byte_t {
	double start;
	double length;
} POKEY_DESERIALIZE_recognize_byte_t;

typedef enum POKEY_DESERIALIZE_datatype {
	POKEY_DESERIALIZE_NONE,
	POKEY_DESERIALIZE_SIGNAL,
	POKEY_DESERIALIZE_BYTE
} POKEY_DESERIALIZE_datatype;

typedef struct POKEY_DESERIALIZE_t POKEY_DESERIALIZE_t;

struct POKEY_DESERIALIZE_t {
	/* Parameters adjustable by user */
	double block_header_deviation; /* Default: 0.25 */
	double bit_deviation; /* Default: 0.25 */
	double stop_bit_deviation; /* Default: higher than IRG length, so no stop bit deviation will be measured. */
	double bit_middle; /* Default: 0.5 */
	unsigned int block_header_length; /* Must be even. Default: 20. */

	/* Internal variables */
	struct {
		char signal;
		double length;
		POKEY_DESERIALIZE_off_t offset;
	} sig;

	double baudrate;
	/* Recognized byte to return on next get call. */
	uint8_t byte;
	/* Number of bytes recognized continuously. */
	unsigned int num_bytes;

	double next_irg;
	/* Even positions hold MARK signal lengths, odd positions hold SPACE signal lengths. */
	struct {
		unsigned int fill;
		unsigned int r_pos;
		unsigned int w_pos;
		unsigned int chk_pos;
		double sum;
		struct POKEY_DESERIALIZE_bit_signal_t *buf;
		unsigned int buf_size; /* Not lower than 20. Must be even. */
	} bit_signals;

	double bit_length;
	double bit_1_0_diff;

	POKEY_DESERIALIZE_recognize_byte_t *recognize_byte_buf;

	int in_flush;

	POKEY_DESERIALIZE_datatype (*process_func)(POKEY_DESERIALIZE_t*);

	/* Used for logging only. */
	A8CAS_FILE *file;
};

void POKEY_DESERIALIZE_init(POKEY_DESERIALIZE_t *deserialize, A8CAS_FILE *file);

A8CAS_errnum POKEY_DESERIALIZE_alloc(POKEY_DESERIALIZE_t *deserialize);

void POKEY_DESERIALIZE_free(POKEY_DESERIALIZE_t *deserialize);

void POKEY_DESERIALIZE_reset(POKEY_DESERIALIZE_t *deserialize);

/* Inserts a signal SIG into the deserializer DESERIALIZE.
   If the insertion results in a datum being available to read, the function
   returns a value different than POKEY_DESERIALIZE_NONE. This means that the
   user should now retrieve all the available data by calling an appropriate
   POKEY_DESERIALIZE_get_* function repeatedly, until it returns
   POKEY_DESERIALIZE_NONE. Only then the user may call POKEY_DESERIALIZE_put
   again. */
POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_put(POKEY_DESERIALIZE_t *deserialize, A8CAS_signal const *sig);

POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_put_with_offset(POKEY_DESERIALIZE_t *deserialize, A8CAS_signal const *sig, POKEY_DESERIALIZE_off_t offset);

/* Flushes the serializer.
   If it results in a datum being available to read, the function returns
   a value different than POKEY_DESERIALIZE_NONE. This means that the user
   should now retrieve all the available data by calling an appropriate
   POKEY_DESERIALIZE_get_* function repeatedly, until it returns
   POKEY_DESERIALIZE_NONE. Only then the user may call POKEY_DESERIALIZE_put
   again. */
POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_flush(POKEY_DESERIALIZE_t *deserialize);

/* Fetches a single signal from the deserializer DESERIALIZE and puts it into
   VALUE (0 or 1) and LENGTH (length in seconds). The return value indicates if
   there is another datum available to read, and what is its type. */
POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_get_signal(POKEY_DESERIALIZE_t *deserialize, uint8_t *value, double *length);

/* Fetches a single byte from the deserializer DESERIALIZE and puts it into
   BYTE, and stored its baudrate in BAUDRATE. The return value indicates if
   there is another datum available to read, and what is its type. */
POKEY_DESERIALIZE_datatype POKEY_DESERIALIZE_get_byte(POKEY_DESERIALIZE_t *deserialize, uint8_t *byte, double *baudrate);

/* Returns file offset of the first signal buffered inside DESERIALIZE but
   not yet processed nor available to get. A negative value is returned if
   there are no buffered signals. */
POKEY_DESERIALIZE_off_t POKEY_DESERIALIZE_buffered_signal_offset(POKEY_DESERIALIZE_t const *deserialize);

/* Functions for setting parameters. They check if a value is correct; if not, they return 1. */
A8CAS_errnum POKEY_DESERIALIZE_set_block_header_deviation(POKEY_DESERIALIZE_t *deserialize, double value);
A8CAS_errnum POKEY_DESERIALIZE_set_bit_deviation(POKEY_DESERIALIZE_t *deserialize, double value);
A8CAS_errnum POKEY_DESERIALIZE_set_stop_bit_deviation(POKEY_DESERIALIZE_t *deserialize, double value);
A8CAS_errnum POKEY_DESERIALIZE_set_bit_middle(POKEY_DESERIALIZE_t *deserialize, double value);
A8CAS_errnum POKEY_DESERIALIZE_set_block_header_length(POKEY_DESERIALIZE_t *deserialize, unsigned int value);

#endif /* POKEY_DESERIALIZE_H */
