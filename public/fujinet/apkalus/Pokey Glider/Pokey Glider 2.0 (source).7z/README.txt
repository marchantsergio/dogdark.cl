
Pokey Glider 2.0                                                   Aug 2, 2009
README.txt

Description:

   8-bit ATARI computer POKEY sound chip synthesizer/sequencer program.


Files:

   PokeyGlider.WAV       : atari++ emulator recording sound file
   PokeyGlider.ATR       : 8-bit ATARI computer disk image
   PokeyGlider.c         : CC65 compiler C language souce code

Instructions:

      You must have an 8-bit ATARI computer emulator in order to run this 
   program, for example, the "atari++" or the "atari800" emulators.
	  
	  Once you have an emulator, attach the ATR disk image and reboot the
   emulator.

      When the ATARI DOS boots up, type L and press RETURN to load binary 
   executable the type in PGSYNTH.XEX
   
     When program starts press Control-L and type TECHNO.  This will load 
   the demo patterns. 
   
     Use the RETURN key to start and stop the synth.  Press Control-#
   where # is any of the number keys 0-9.  This will select any of the 10
   patterns available.
   
     When the program is running you may press the HELP key for reference.
   On the atari++ emulator, this is the F5 key, on the atari800 it's F6.  
	 
Author:

  Bart Jaszcz
  bpj1138@yahoo.com

  
